package com.project.financeapi.dto.investment.request;

import com.project.financeapi.enumSystem.FixedIncomeType;
import com.project.financeapi.enumSystem.IndexerType;
import java.util.List;
import java.util.UUID;

public record CreateProductDTO(
        UUID accountId, // A conta da corretora/banco onde o produto reside
        String name,    // Ex: "Mercado Pago", "CDB Nubank"
        IndexerType indexer,
        FixedIncomeType type,
        List<TierRequestDTO> tiers // Regras de rendimento (0 a 4999 = 115%, etc)
) {}