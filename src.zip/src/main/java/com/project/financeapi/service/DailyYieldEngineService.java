package com.project.financeapi.service;

import com.project.financeapi.entity.*;
import com.project.financeapi.enumSystem.InvestmentTransactionType;
import com.project.financeapi.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class DailyYieldEngineService {

    private final InvestmentProductRepository productRepository;
    private final InvestmentTransactionRepository transactionRepository;
    private final MarketIndexRateRepository marketIndexRateRepository;
    private final HolidayRepository holidayRepository;

    @Transactional
    public void processPendingYieldsForAccount(UUID accountId) {
        log.info(">>> Iniciando processamento de rendimentos para a conta: {}", accountId);
        productRepository.findAllActiveByAccountIdWithDetails(accountId).forEach(this::processYieldForProduct);
        log.info("<<< Processamento finalizado para a conta: {}", accountId);
    }

    private void processYieldForProduct(InvestmentProduct product) {
        log.info("--- Avaliando Produto: {} (ID: {}) ---", product.getName(), product.getId());

        // A REGRA: Avalia até HOJE (Abolida a trava de D-1)
        LocalDate endDate = LocalDate.now();

        List<FixedIncomeLot> allProductLots = product.getBoxes().stream()
                .flatMap(box -> box.getLots().stream()).toList();

        if (allProductLots.isEmpty() || product.getTiers().isEmpty()) {
            return;
        }

        // Mantém a varredura para garantir que nenhum dia para trás fique sem rendimento caso o servidor caia
        LocalDate startDate = allProductLots.stream()
                .map(lot -> lot.getLastYieldDate().orElse(lot.getLedgerStartDate().minusDays(1)))
                .min(LocalDate::compareTo).orElse(endDate).plusDays(1);

        if (startDate.isAfter(endDate)) {
            log.info("Todos os rendimentos já estão em dia para este produto.");
            return;
        }

        List<InvestmentTransaction> newTransactions = new ArrayList<>();

        for (LocalDate loopDate = startDate; !loopDate.isAfter(endDate); loopDate = loopDate.plusDays(1)) {

            // O SEGREDO ESTÁ AQUI: Criamos uma variável final para o Java permitir o uso no Lambda
            final LocalDate processDate = loopDate;

            // REGRA 1: É dia útil?
            if (processDate.getDayOfWeek() == DayOfWeek.SATURDAY || processDate.getDayOfWeek() == DayOfWeek.SUNDAY) {
                log.debug("Dia {}: Fim de semana. Pulando.", processDate);
                continue;
            }
            if (holidayRepository.existsByDate(processDate)) {
                log.debug("Dia {}: Feriado detectado. Pulando.", processDate);
                continue;
            }

            // REGRA 2: Pega sempre a última taxa registrada no banco (Fallback automático)
            MarketIndexRate lastKnownRate = marketIndexRateRepository
                    .findFirstByIndexerTypeAndReferenceDateLessThanEqualOrderByReferenceDateDesc(product.getIndexer(), processDate)
                    .orElse(null);

            if (lastKnownRate == null) {
                log.warn("Dia {}: Nenhuma taxa de mercado anterior conhecida no banco! Pulando.", processDate);
                continue;
            }

            BigDecimal baseMarketRate = lastKnownRate.getRateValue().divide(BigDecimal.valueOf(100), 8, RoundingMode.HALF_UP);
            BigDecimal superBalance = BigDecimal.ZERO;
            Map<FixedIncomeLot, BigDecimal> activeLotsEod = new HashMap<>();

            for (FixedIncomeLot lot : allProductLots) {
                // REGRA 3: Não existe lançamento de transação de rendimento hoje?
                boolean hasYieldToday = lot.getTransactions().stream()
                        .anyMatch(t -> t.getType() == InvestmentTransactionType.DAILY_YIELD && t.getReferenceDate().equals(processDate));
                if (hasYieldToday) continue;

                // Captura o saldo do lote independentemente de quando foi o último lançamento
                BigDecimal eodBalance = lot.projectStateUpTo(processDate).grossBalance();
                if (eodBalance.compareTo(BigDecimal.ZERO) > 0) {
                    activeLotsEod.put(lot, eodBalance);
                    superBalance = superBalance.add(eodBalance);
                }
            }

            if (superBalance.compareTo(BigDecimal.ZERO) <= 0) continue;

            log.debug("Dia {}: Processando rendimento sobre R$ {} usando Taxa: {}", processDate, superBalance, lastKnownRate.getRateValue());

            BigDecimal totalYieldForDay = BigDecimal.ZERO;
            for (InvestmentTier tier : product.getTiers()) {
                BigDecimal min = tier.getMinBalance();
                BigDecimal max = tier.getMaxBalance() != null ? tier.getMaxBalance() : BigDecimal.valueOf(Long.MAX_VALUE);

                if (superBalance.compareTo(min) > 0) {
                    BigDecimal slice = superBalance.min(max).subtract(min);
                    BigDecimal tierMultiplier = tier.getRateMultiplier().divide(BigDecimal.valueOf(100), 8, RoundingMode.HALF_UP);
                    BigDecimal sliceYield = slice.multiply(baseMarketRate).multiply(tierMultiplier).setScale(4, RoundingMode.HALF_UP);
                    totalYieldForDay = totalYieldForDay.add(sliceYield);
                }
            }

            // REGRA 4: Cria os lançamentos
            for (Map.Entry<FixedIncomeLot, BigDecimal> entry : activeLotsEod.entrySet()) {
                FixedIncomeLot lot = entry.getKey();
                BigDecimal ratio = entry.getValue().divide(superBalance, 8, RoundingMode.HALF_UP);
                BigDecimal lotYield = totalYieldForDay.multiply(ratio).setScale(4, RoundingMode.HALF_UP);

                InvestmentTransaction tx = InvestmentTransaction.builder()
                        .lot(lot)
                        .type(InvestmentTransactionType.DAILY_YIELD)
                        .referenceDate(processDate)
                        .grossAmount(lotYield)
                        .amount(lotYield)
                        .irTax(BigDecimal.ZERO)
                        .iofTax(BigDecimal.ZERO)
                        .appliedMarketRate(lastKnownRate.getRateValue())
                        .description("Rend. Diário Consolidado")
                        .build();

                newTransactions.add(tx);
                lot.getTransactions().add(tx);
            }
        }

        if (!newTransactions.isEmpty()) {
            log.info("Salvando {} novas transações de rendimento para o Produto {}.", newTransactions.size(), product.getName());
            transactionRepository.saveAll(newTransactions);
        }
    }
}