package com.project.financeapi.repository;

import com.project.financeapi.entity.InvestmentProduct;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface InvestmentProductRepository extends JpaRepository<InvestmentProduct, UUID> {
    @Query("SELECT DISTINCT p FROM InvestmentProduct p " +
            "LEFT JOIN FETCH p.tiers " +
            "LEFT JOIN FETCH p.boxes b " +
            "LEFT JOIN FETCH b.lots l " +
            "LEFT JOIN FETCH l.transactions " +
            "WHERE p.account.id = :accountId") // <-- Removemos o AND p.status = 'ACTIVE'
    List<InvestmentProduct> findAllActiveByAccountIdWithDetails(@Param("accountId") UUID accountId);
}