package com.project.financeapi.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

// --- 3. CAIXINHA (SUB-CONTA LÓGICA) ---
@Entity
@Table(name = "investment_boxes")
@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class InvestmentBox {
    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id", nullable = false)
    private InvestmentProduct product;

    private String name;

    @Builder.Default
    @OneToMany(mappedBy = "box", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<FixedIncomeLot> lots = new HashSet<>();

    @Transient
    public boolean hasBalance() {
        if (this.lots == null || this.lots.isEmpty()) {
            return false;
        }
        // Verifica se algum lote possui saldo bruto maior que zero
        return this.lots.stream()
                .anyMatch(lot -> lot.projectState().grossBalance().compareTo(java.math.BigDecimal.ZERO) > 0);
    }
}