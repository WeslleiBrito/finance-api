package com.project.financeapi.entity.base;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.project.financeapi.dto.account.AccountResponseDTO;
import com.project.financeapi.dto.account.AccountUpdateDTO;
import com.project.financeapi.entity.Bank;
import com.project.financeapi.enumSystem.AccountStatus;
import com.project.financeapi.enumSystem.AccountType;
import com.project.financeapi.entity.Transaction;
import com.project.financeapi.entity.User;
import com.project.financeapi.enumSystem.MovementType;
import com.project.financeapi.enumSystem.MovementDirection;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


@Getter
@Setter
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class AccountBase {

    @Id
    @Column(length = 36)
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Setter
    @Column(nullable = false, length = 100)
    private String name;

    @Setter
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AccountType type;

    @Setter
    @Enumerated(EnumType.STRING)
    @Column(name = "account_status", nullable = false)
    private AccountStatus status = AccountStatus.ACTIVE;

    @Column(name = "initial_value", nullable = false)
    private BigDecimal initialValue;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private LocalDateTime creationDate;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User accountHolder;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "bank_id")
    private Bank bank;

    @JsonManagedReference
    @OneToMany(mappedBy = "account", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Transaction> transactions = new ArrayList<>();

    public AccountBase(AccountType type, User accountHolder, String name, BigDecimal initialValue, Bank bank) {
        this.type = type;
        this.accountHolder = accountHolder;
        this.initialValue = initialValue != null ? initialValue : BigDecimal.ZERO;
        this.bank = bank;
        this.name = name;
    }

    public AccountBase() {
    }

    public BigDecimal getBalance() {
        if(transactions == null || transactions.isEmpty()){
            return initialValue;
        }

        return initialValue.add(
                transactions.stream()
                        .map(t -> {
                            // 1. Pega o valor real que movimentou o caixa (já contabilizando juros, multas e descontos)
                            BigDecimal effectiveValue = t.getEffectiveAmount() != null ? t.getEffectiveAmount() : BigDecimal.ZERO;

                            // 2. Olha para a DIREÇÃO da transação, e não para a parcela.
                            // Se o estorno inverteu a direção para INFLOW, ele vai somar o dinheiro de volta!
                            return t.getMovementDirection() == MovementDirection.INFLOW
                                    ? effectiveValue
                                    : effectiveValue.negate();
                        })
                        .reduce(BigDecimal.ZERO, BigDecimal::add)
        );
    }

    public abstract AccountResponseDTO toDTO();

    public void updateFrom(AccountUpdateDTO dto) {

        if(dto.name() != null){
            this.name = dto.name();
        }

    }

}
