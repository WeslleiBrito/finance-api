package com.project.financeapi.entity;

import com.project.financeapi.entity.base.AccountBase;
import com.project.financeapi.enumSystem.FixedIncomeType;
import com.project.financeapi.enumSystem.IndexerType;
import jakarta.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

// --- 1. PRODUTO (POOL GLOBAL) ---
@Entity
@Table(name = "investment_products")
@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class InvestmentProduct {
    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "account_id", nullable = false)
    private AccountBase account;

    private String name;

    @Enumerated(EnumType.STRING)
    private IndexerType indexer;

    @Enumerated(EnumType.STRING)
    private FixedIncomeType type;

    @Builder.Default
    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<InvestmentTier> tiers = new HashSet<>();

    @Builder.Default
    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<InvestmentBox> boxes = new HashSet<>();

    @Transient
    public boolean isActive() {
        // Se o produto não tem nenhuma caixinha, ele não tem saldo.
        // (Nota: Se quiser que produtos recém-criados e vazios apareçam, mude o return para true)
        if (this.boxes == null || this.boxes.isEmpty()) {
            return false;
        }

        // O produto está ativo se pelo menos UMA caixinha tiver saldo
        return this.boxes.stream().anyMatch(InvestmentBox::hasBalance);
    }
}